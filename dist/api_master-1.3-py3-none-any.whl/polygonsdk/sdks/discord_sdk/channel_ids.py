"""YOUR CHANNEL NAMES AND IDS HERE"""

channels = {}
