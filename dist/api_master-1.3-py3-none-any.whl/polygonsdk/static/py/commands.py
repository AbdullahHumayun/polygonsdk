stream_commands = {
    "time_and_sales": "Returns real-time time and sales data for 100 ticks.",
    "double_quote": "Choose two stocks and stream their price in real-time for 200 ticks.",
    "quote": "Choose a stock and stream its price in real-time for 200 ticks.",
    "double_crypto": "Choose two crypto coins and stream their price in real-time for 200 ticks.",
    "crypto": "Choose a crypto coin and stream its price in real-time for 200 ticks.",
    "topvolume": "Find the top option for volume in real time.",
    "tits": "Does exactly what it says..."
}